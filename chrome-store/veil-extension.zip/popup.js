"use strict";
(() => {
  // src/i18n.ts
  var STRINGS = {
    en: {
      app_name: "VEIL",
      start_session: "Start Secure Session",
      complete_handshake: "Complete Handshake",
      waiting: "Waiting for reply...",
      verified: "Session Verified",
      no_session: "No active secure session.",
      send_encrypted: "Send Encrypted",
      end_session: "End Session",
      settings: "Settings",
      copy: "Copy",
      copied: "Copied!",
      cancel: "Cancel",
      type_message: "Type your message...",
      send_invite: "Send this to your contact:",
      copy_invite: "Copy Invite Code",
      waiting_reply: "Waiting for their reply...",
      manual_tools: "Manual Tools",
      paste_decrypt: "Paste ciphertext to decrypt",
      decrypt: "Decrypt",
      onboarding_input: "To auto-send encrypted messages, click your chat input box now.",
      onboarding_send: "Now click the Send button.",
      onboarding_done: "Setup complete! Auto-send is configured for this site.",
      onboarding_reset: "Re-configure input detection",
      language: "Language",
      secure: "Secure",
      fingerprint: "Fingerprint",
      fingerprint_match: "Fingerprint verified - session is secure.",
      fingerprint_mismatch: "WARNING: Fingerprint mismatch! Possible MITM attack. Do NOT proceed.",
      compare_fingerprint: "Compare this fingerprint with your contact via a separate channel:",
      you: "You",
      them: "Them",
      session_ended: "Session ended. Keys wiped.",
      copy_fallback: "Could not auto-send. Copy and paste manually:",
      what_veil_does: "Veil encrypts your messages before they leave your browser. The messenger platform only sees encrypted text.",
      what_veil_cannot: "Veil cannot protect against device-level compromise (malware, spyware, keyloggers), physical access to an unlocked device, or metadata (who you talk to, when, how often).",
      hygiene_note: "Close your browser when you are not actively chatting. While the browser is open, session keys exist in RAM.",
      first_launch_welcome: "Welcome to Veil",
      choose_language: "Choose your language",
      handshake_received: "Handshake invite detected. Complete the handshake?",
      accept_handshake: "Accept & Connect",
      step1_title: "Step 1: Create invite",
      step1_desc: "Click below to generate a secure invite code. Send this code to your contact through the chat.",
      step2_title: "Step 2: Wait for response",
      step2_desc: 'Your contact must open Veil, click "I Received an Invite", and paste your code. They will send back their own code.',
      step3_title: "Step 3: Connected!",
      step3_desc: "Both sides verified. You can now send encrypted messages.",
      create_invite: "Create Invite",
      i_received_invite: "I Received an Invite",
      paste_invite_prompt: "Paste the invite code you received from your contact:",
      paste_here: "Paste invite code here...",
      connect: "Connect",
      status_generating: "Generating secure keys...",
      status_connected: "Connected & Verified",
      status_waiting: "Waiting for contact's response...",
      how_it_works: "How it works",
      how_it_works_desc: "1. One person creates an invite and sends the code\n2. The other person pastes the code and connects\n3. Both sides are now encrypted end-to-end",
      or_paste_reply: "Or paste the reply code manually:",
      paste_reply_here: "Paste reply code here...",
      submit_reply: "Submit Reply",
      paste_incoming: "Paste incoming message to decrypt:",
      paste_incoming_here: "Paste encrypted message here...",
      decrypt_incoming: "Decrypt",
      // Popup UI
      popup_connected: "Connected",
      popup_waiting_response: "Waiting for response...",
      popup_no_session: "No session",
      popup_compare_peer: "Compare this with your peer",
      popup_inband: "In-band",
      popup_server: "Server",
      popup_setup_site: "Set up for this site",
      popup_reconfigure: "Re-configure input",
      popup_setup_needed: "Set up input detection for this site first.",
      // Verification statuses
      verify_checking: "Checking...",
      verify_verified: "Verified",
      verify_mismatch: "MISMATCH",
      verify_unavailable: "Unavailable",
      // Tooltips
      tip_status: "Shows whether an encrypted session is active with a peer on this page",
      tip_fingerprint: "Unique session ID \u2014 compare this with your peer through a different app (call, text) to confirm no one is intercepting",
      tip_inband: "Checks fingerprint through the messenger itself \u2014 catches bugs but not a determined attacker",
      tip_server: "Checks fingerprint through Veil's server \u2014 an independent channel that catches man-in-the-middle attacks",
      tip_start_session: "Scan the chat for an existing invite or send one \u2014 the other person must also start a session",
      tip_end_session: "Sends an end signal to your peer and clears all keys from memory",
      tip_setup: "Teach Veil which input box and send button this site uses \u2014 needed once per site",
      tip_reconfigure: "Re-detect the input box and send button for this site",
      tip_language: "Switch interface language"
    },
    fa: {
      app_name: "VEIL",
      start_session: "\u0634\u0631\u0648\u0639 \u06AF\u0641\u062A\u06AF\u0648\u06CC \u0627\u0645\u0646",
      complete_handshake: "\u062A\u06A9\u0645\u06CC\u0644 \u062F\u0633\u062A\u200C\u062F\u0627\u062F",
      waiting: "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E...",
      verified: "\u062C\u0644\u0633\u0647 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F",
      no_session: "\u0647\u06CC\u0686 \u062C\u0644\u0633\u0647 \u0627\u0645\u0646\u06CC \u0641\u0639\u0627\u0644 \u0646\u06CC\u0633\u062A.",
      send_encrypted: "\u0627\u0631\u0633\u0627\u0644 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647",
      end_session: "\u067E\u0627\u06CC\u0627\u0646 \u062C\u0644\u0633\u0647",
      settings: "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A",
      copy: "\u06A9\u067E\u06CC",
      copied: "\u06A9\u067E\u06CC \u0634\u062F!",
      cancel: "\u0644\u063A\u0648",
      type_message: "\u067E\u06CC\u0627\u0645 \u062E\u0648\u062F \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F...",
      send_invite: "\u0627\u06CC\u0646 \u0631\u0627 \u0628\u0631\u0627\u06CC \u0645\u062E\u0627\u0637\u0628 \u062E\u0648\u062F \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F:",
      copy_invite: "\u06A9\u067E\u06CC \u06A9\u062F \u062F\u0639\u0648\u062A",
      waiting_reply: "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E \u0622\u0646\u200C\u0647\u0627...",
      manual_tools: "\u0627\u0628\u0632\u0627\u0631\u0647\u0627\u06CC \u062F\u0633\u062A\u06CC",
      paste_decrypt: "\u0645\u062A\u0646 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647 \u0631\u0627 \u0628\u0631\u0627\u06CC \u0631\u0645\u0632\u06AF\u0634\u0627\u06CC\u06CC \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F",
      decrypt: "\u0631\u0645\u0632\u06AF\u0634\u0627\u06CC\u06CC",
      onboarding_input: "\u0628\u0631\u0627\u06CC \u0627\u0631\u0633\u0627\u0644 \u062E\u0648\u062F\u06A9\u0627\u0631\u060C \u0631\u0648\u06CC \u06A9\u0627\u062F\u0631 \u0648\u0631\u0648\u062F\u06CC \u067E\u06CC\u0627\u0645 \u06A9\u0644\u06CC\u06A9 \u06A9\u0646\u06CC\u062F.",
      onboarding_send: "\u062D\u0627\u0644\u0627 \u0631\u0648\u06CC \u062F\u06A9\u0645\u0647 \u0627\u0631\u0633\u0627\u0644 \u06A9\u0644\u06CC\u06A9 \u06A9\u0646\u06CC\u062F.",
      onboarding_done: "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u06A9\u0627\u0645\u0644 \u0634\u062F! \u0627\u0631\u0633\u0627\u0644 \u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0633\u0627\u06CC\u062A \u067E\u06CC\u06A9\u0631\u0628\u0646\u062F\u06CC \u0634\u062F.",
      onboarding_reset: "\u067E\u06CC\u06A9\u0631\u0628\u0646\u062F\u06CC \u0645\u062C\u062F\u062F \u062A\u0634\u062E\u06CC\u0635 \u0648\u0631\u0648\u062F\u06CC",
      language: "\u0632\u0628\u0627\u0646",
      secure: "\u0627\u0645\u0646",
      fingerprint: "\u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A",
      fingerprint_match: "\u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F - \u062C\u0644\u0633\u0647 \u0627\u0645\u0646 \u0627\u0633\u062A.",
      fingerprint_mismatch: "\u0647\u0634\u062F\u0627\u0631: \u0639\u062F\u0645 \u062A\u0637\u0627\u0628\u0642 \u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A! \u062D\u0645\u0644\u0647 MITM \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A. \u0627\u062F\u0627\u0645\u0647 \u0646\u062F\u0647\u06CC\u062F.",
      compare_fingerprint: "\u0627\u06CC\u0646 \u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A \u0631\u0627 \u0627\u0632 \u06A9\u0627\u0646\u0627\u0644 \u062F\u06CC\u06AF\u0631\u06CC \u0628\u0627 \u0645\u062E\u0627\u0637\u0628 \u0645\u0642\u0627\u06CC\u0633\u0647 \u06A9\u0646\u06CC\u062F:",
      you: "\u0634\u0645\u0627",
      them: "\u0622\u0646\u200C\u0647\u0627",
      session_ended: "\u062C\u0644\u0633\u0647 \u067E\u0627\u06CC\u0627\u0646 \u06CC\u0627\u0641\u062A. \u06A9\u0644\u06CC\u062F\u0647\u0627 \u067E\u0627\u06A9 \u0634\u062F\u0646\u062F.",
      copy_fallback: "\u0627\u0631\u0633\u0627\u0644 \u062E\u0648\u062F\u06A9\u0627\u0631 \u0645\u0645\u06A9\u0646 \u0646\u0634\u062F. \u06A9\u067E\u06CC \u06A9\u0631\u062F\u0647 \u0648 \u062F\u0633\u062A\u06CC \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F:",
      what_veil_does: "Veil \u067E\u06CC\u0627\u0645\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0631\u0627 \u0642\u0628\u0644 \u0627\u0632 \u062E\u0631\u0648\u062C \u0627\u0632 \u0645\u0631\u0648\u0631\u06AF\u0631 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F. \u067E\u0644\u062A\u0641\u0631\u0645 \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646 \u0641\u0642\u0637 \u0645\u062A\u0646 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647 \u0631\u0627 \u0645\u06CC\u200C\u0628\u06CC\u0646\u062F.",
      what_veil_cannot: "Veil \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u062F\u0631 \u0628\u0631\u0627\u0628\u0631 \u0622\u0644\u0648\u062F\u06AF\u06CC \u062F\u0633\u062A\u06AF\u0627\u0647 (\u0628\u062F\u0627\u0641\u0632\u0627\u0631\u060C \u062C\u0627\u0633\u0648\u0633\u200C\u0627\u0641\u0632\u0627\u0631\u060C \u06A9\u06CC\u200C\u0644\u0627\u06AF\u0631)\u060C \u062F\u0633\u062A\u0631\u0633\u06CC \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u0628\u0647 \u062F\u0633\u062A\u06AF\u0627\u0647 \u0628\u0627\u0632\u060C \u06CC\u0627 \u0641\u0631\u0627\u062F\u0627\u062F\u0647 (\u0628\u0627 \u06A9\u06CC \u0635\u062D\u0628\u062A \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F\u060C \u06A9\u06CC\u060C \u0686\u0642\u062F\u0631) \u0645\u062D\u0627\u0641\u0638\u062A \u06A9\u0646\u062F.",
      hygiene_note: "\u0648\u0642\u062A\u06CC \u0686\u062A \u0646\u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F \u0645\u0631\u0648\u0631\u06AF\u0631 \u0631\u0627 \u0628\u0628\u0646\u062F\u06CC\u062F. \u062A\u0627 \u0632\u0645\u0627\u0646\u06CC \u06A9\u0647 \u0645\u0631\u0648\u0631\u06AF\u0631 \u0628\u0627\u0632 \u0627\u0633\u062A\u060C \u06A9\u0644\u06CC\u062F\u0647\u0627\u06CC \u062C\u0644\u0633\u0647 \u062F\u0631 \u062D\u0627\u0641\u0638\u0647 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u0646\u062F.",
      first_launch_welcome: "\u0628\u0647 Veil \u062E\u0648\u0634 \u0622\u0645\u062F\u06CC\u062F",
      choose_language: "\u0632\u0628\u0627\u0646 \u062E\u0648\u062F \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F",
      handshake_received: "\u062F\u0639\u0648\u062A \u062F\u0633\u062A\u200C\u062F\u0627\u062F \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0634\u062F. \u062F\u0633\u062A\u200C\u062F\u0627\u062F \u0631\u0627 \u062A\u06A9\u0645\u06CC\u0644 \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F\u061F",
      accept_handshake: "\u0642\u0628\u0648\u0644 \u0648 \u0627\u062A\u0635\u0627\u0644",
      step1_title: "\u0645\u0631\u062D\u0644\u0647 \u06F1: \u0633\u0627\u062E\u062A \u062F\u0639\u0648\u062A",
      step1_desc: "\u0628\u0631\u0627\u06CC \u0633\u0627\u062E\u062A \u06A9\u062F \u062F\u0639\u0648\u062A \u0627\u0645\u0646 \u06A9\u0644\u06CC\u06A9 \u06A9\u0646\u06CC\u062F. \u0627\u06CC\u0646 \u06A9\u062F \u0631\u0627 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0686\u062A \u0628\u0631\u0627\u06CC \u0645\u062E\u0627\u0637\u0628 \u062E\u0648\u062F \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F.",
      step2_title: "\u0645\u0631\u062D\u0644\u0647 \u06F2: \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E",
      step2_desc: "\u0645\u062E\u0627\u0637\u0628 \u0634\u0645\u0627 \u0628\u0627\u06CC\u062F Veil \u0631\u0627 \u0628\u0627\u0632 \u06A9\u0646\u062F\u060C \xAB\u06A9\u062F \u062F\u0639\u0648\u062A \u062F\u0631\u06CC\u0627\u0641\u062A \u06A9\u0631\u062F\u0645\xBB \u0631\u0627 \u0628\u0632\u0646\u062F \u0648 \u06A9\u062F \u0634\u0645\u0627 \u0631\u0627 \u0628\u0686\u0633\u0628\u0627\u0646\u062F.",
      step3_title: "\u0645\u0631\u062D\u0644\u0647 \u06F3: \u0645\u062A\u0635\u0644 \u0634\u062F!",
      step3_desc: "\u0647\u0631 \u062F\u0648 \u0637\u0631\u0641 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0646\u062F. \u0627\u06A9\u0646\u0648\u0646 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u067E\u06CC\u0627\u0645 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647 \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F.",
      create_invite: "\u0633\u0627\u062E\u062A \u062F\u0639\u0648\u062A",
      i_received_invite: "\u06A9\u062F \u062F\u0639\u0648\u062A \u062F\u0631\u06CC\u0627\u0641\u062A \u06A9\u0631\u062F\u0645",
      paste_invite_prompt: "\u06A9\u062F \u062F\u0639\u0648\u062A\u06CC \u06A9\u0647 \u0627\u0632 \u0645\u062E\u0627\u0637\u0628 \u062F\u0631\u06CC\u0627\u0641\u062A \u06A9\u0631\u062F\u06CC\u062F \u0631\u0627 \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F:",
      paste_here: "\u06A9\u062F \u062F\u0639\u0648\u062A \u0631\u0627 \u0627\u06CC\u0646\u062C\u0627 \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F...",
      connect: "\u0627\u062A\u0635\u0627\u0644",
      status_generating: "\u062F\u0631 \u062D\u0627\u0644 \u0633\u0627\u062E\u062A \u06A9\u0644\u06CC\u062F\u0647\u0627\u06CC \u0627\u0645\u0646...",
      status_connected: "\u0645\u062A\u0635\u0644 \u0648 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647",
      status_waiting: "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E \u0645\u062E\u0627\u0637\u0628...",
      how_it_works: "\u0646\u062D\u0648\u0647 \u06A9\u0627\u0631",
      how_it_works_desc: "\u06F1. \u06CC\u06A9 \u0646\u0641\u0631 \u062F\u0639\u0648\u062A \u0645\u06CC\u200C\u0633\u0627\u0632\u062F \u0648 \u06A9\u062F \u0631\u0627 \u0627\u0631\u0633\u0627\u0644 \u0645\u06CC\u200C\u06A9\u0646\u062F\n\u06F2. \u0646\u0641\u0631 \u062F\u06CC\u06AF\u0631 \u06A9\u062F \u0631\u0627 \u0645\u06CC\u200C\u0686\u0633\u0628\u0627\u0646\u062F \u0648 \u0645\u062A\u0635\u0644 \u0645\u06CC\u200C\u0634\u0648\u062F\n\u06F3. \u0647\u0631 \u062F\u0648 \u0637\u0631\u0641 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0633\u0631\u062A\u0627\u0633\u0631\u06CC \u062F\u0627\u0631\u0646\u062F",
      or_paste_reply: "\u06CC\u0627 \u06A9\u062F \u067E\u0627\u0633\u062E \u0631\u0627 \u062F\u0633\u062A\u06CC \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F:",
      paste_reply_here: "\u06A9\u062F \u067E\u0627\u0633\u062E \u0631\u0627 \u0627\u06CC\u0646\u062C\u0627 \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F...",
      submit_reply: "\u062B\u0628\u062A \u067E\u0627\u0633\u062E",
      paste_incoming: "\u067E\u06CC\u0627\u0645 \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC \u0631\u0627 \u0628\u0631\u0627\u06CC \u0631\u0645\u0632\u06AF\u0634\u0627\u06CC\u06CC \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F:",
      paste_incoming_here: "\u067E\u06CC\u0627\u0645 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647 \u0631\u0627 \u0628\u0686\u0633\u0628\u0627\u0646\u06CC\u062F...",
      decrypt_incoming: "\u0631\u0645\u0632\u06AF\u0634\u0627\u06CC\u06CC",
      // Popup UI
      popup_connected: "\u0645\u062A\u0635\u0644",
      popup_waiting_response: "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E...",
      popup_no_session: "\u0628\u062F\u0648\u0646 \u062C\u0644\u0633\u0647",
      popup_compare_peer: "\u0627\u06CC\u0646 \u0631\u0627 \u0628\u0627 \u0645\u062E\u0627\u0637\u0628 \u062E\u0648\u062F \u0645\u0642\u0627\u06CC\u0633\u0647 \u06A9\u0646\u06CC\u062F",
      popup_inband: "\u062F\u0631\u0648\u0646\u200C\u06A9\u0627\u0646\u0627\u0644\u06CC",
      popup_server: "\u0633\u0631\u0648\u0631",
      popup_setup_site: "\u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0633\u0627\u06CC\u062A",
      popup_reconfigure: "\u067E\u06CC\u06A9\u0631\u0628\u0646\u062F\u06CC \u0645\u062C\u062F\u062F \u0648\u0631\u0648\u062F\u06CC",
      popup_setup_needed: "\u0627\u0628\u062A\u062F\u0627 \u062A\u0634\u062E\u06CC\u0635 \u0648\u0631\u0648\u062F\u06CC \u0631\u0627 \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0633\u0627\u06CC\u062A \u062A\u0646\u0638\u06CC\u0645 \u06A9\u0646\u06CC\u062F.",
      // Verification statuses
      verify_checking: "\u062F\u0631 \u062D\u0627\u0644 \u0628\u0631\u0631\u0633\u06CC...",
      verify_verified: "\u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647",
      verify_mismatch: "\u0639\u062F\u0645 \u062A\u0637\u0627\u0628\u0642",
      verify_unavailable: "\u0646\u0627\u0645\u0648\u062C\u0648\u062F",
      // Tooltips
      tip_status: "\u0646\u0634\u0627\u0646 \u0645\u06CC\u200C\u062F\u0647\u062F \u0622\u06CC\u0627 \u06CC\u06A9 \u062C\u0644\u0633\u0647 \u0631\u0645\u0632\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F\u0647 \u0628\u0627 \u0645\u062E\u0627\u0637\u0628 \u062F\u0631 \u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0641\u0639\u0627\u0644 \u0627\u0633\u062A",
      tip_fingerprint: "\u0634\u0646\u0627\u0633\u0647 \u06CC\u06A9\u062A\u0627\u06CC \u062C\u0644\u0633\u0647 \u2014 \u0627\u06CC\u0646 \u0631\u0627 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0628\u0631\u0646\u0627\u0645\u0647 \u062F\u06CC\u06AF\u0631\u06CC (\u062A\u0645\u0627\u0633\u060C \u067E\u06CC\u0627\u0645\u06A9) \u0628\u0627 \u0645\u062E\u0627\u0637\u0628 \u0645\u0642\u0627\u06CC\u0633\u0647 \u06A9\u0646\u06CC\u062F \u062A\u0627 \u0645\u0637\u0645\u0626\u0646 \u0634\u0648\u06CC\u062F \u06A9\u0633\u06CC \u062F\u0631 \u0645\u06CC\u0627\u0646 \u0646\u06CC\u0633\u062A",
      tip_inband: "\u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A \u0631\u0627 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u062E\u0648\u062F \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646 \u0628\u0631\u0631\u0633\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F \u2014 \u062E\u0637\u0627\u0647\u0627 \u0631\u0627 \u0645\u06CC\u200C\u06AF\u06CC\u0631\u062F \u0627\u0645\u0627 \u0646\u0647 \u062D\u0645\u0644\u0647 \u0647\u062F\u0641\u0645\u0646\u062F",
      tip_server: "\u0627\u062B\u0631 \u0627\u0646\u06AF\u0634\u062A \u0631\u0627 \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0633\u0631\u0648\u0631 Veil \u0628\u0631\u0631\u0633\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F \u2014 \u06A9\u0627\u0646\u0627\u0644 \u0645\u0633\u062A\u0642\u0644 \u0628\u0631\u0627\u06CC \u062A\u0634\u062E\u06CC\u0635 \u062D\u0645\u0644\u0627\u062A \u0645\u06CC\u0627\u0646\u06CC",
      tip_start_session: "\u0686\u062A \u0631\u0627 \u0628\u0631\u0627\u06CC \u062F\u0639\u0648\u062A \u0645\u0648\u062C\u0648\u062F \u0627\u0633\u06A9\u0646 \u06A9\u0646\u06CC\u062F \u06CC\u0627 \u06CC\u06A9\u06CC \u0628\u0641\u0631\u0633\u062A\u06CC\u062F \u2014 \u0637\u0631\u0641 \u0645\u0642\u0627\u0628\u0644 \u0647\u0645 \u0628\u0627\u06CC\u062F \u062C\u0644\u0633\u0647 \u0631\u0627 \u0634\u0631\u0648\u0639 \u06A9\u0646\u062F",
      tip_end_session: "\u0633\u06CC\u06AF\u0646\u0627\u0644 \u067E\u0627\u06CC\u0627\u0646 \u0631\u0627 \u0628\u0647 \u0645\u062E\u0627\u0637\u0628 \u0645\u06CC\u200C\u0641\u0631\u0633\u062A\u062F \u0648 \u0647\u0645\u0647 \u06A9\u0644\u06CC\u062F\u0647\u0627 \u0631\u0627 \u0627\u0632 \u062D\u0627\u0641\u0638\u0647 \u067E\u0627\u06A9 \u0645\u06CC\u200C\u06A9\u0646\u062F",
      tip_setup: "\u0628\u0647 Veil \u06CC\u0627\u062F \u062F\u0647\u06CC\u062F \u06A9\u0647 \u06A9\u0627\u062F\u0631 \u0648\u0631\u0648\u062F\u06CC \u0648 \u062F\u06A9\u0645\u0647 \u0627\u0631\u0633\u0627\u0644 \u0627\u06CC\u0646 \u0633\u0627\u06CC\u062A \u06A9\u062C\u0627\u0633\u062A \u2014 \u0641\u0642\u0637 \u06CC\u06A9\u200C\u0628\u0627\u0631 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A",
      tip_reconfigure: "\u06A9\u0627\u062F\u0631 \u0648\u0631\u0648\u062F\u06CC \u0648 \u062F\u06A9\u0645\u0647 \u0627\u0631\u0633\u0627\u0644 \u0627\u06CC\u0646 \u0633\u0627\u06CC\u062A \u0631\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0634\u062E\u06CC\u0635 \u062F\u0647\u06CC\u062F",
      tip_language: "\u062A\u063A\u06CC\u06CC\u0631 \u0632\u0628\u0627\u0646 \u0631\u0627\u0628\u0637 \u06A9\u0627\u0631\u0628\u0631\u06CC"
    }
  };
  var _veilLang = "en";
  function t(key) {
    return STRINGS[_veilLang] && STRINGS[_veilLang][key] || STRINGS.en[key] || key;
  }
  function setLang(lang) {
    _veilLang = lang;
  }
  function getLang() {
    return _veilLang;
  }

  // src/popup.ts
  function sendToContent(msg) {
    chrome.runtime.sendMessage({ target: "content", ...msg });
  }
  function getHostname() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_TAB_HOSTNAME" }, (resp) => {
        resolve(resp?.hostname ?? "");
      });
    });
  }
  function getSessionState() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { target: "content", type: "GET_SESSION_STATE" },
        (response) => {
          if (!response) {
            resolve({});
            return;
          }
          resolve({
            veil_handshake_state: response.handshakeState ?? "idle",
            veil_fingerprint: response.fingerprint ?? void 0,
            veil_public_key: response.myPublicKeyBase64 ?? void 0,
            veil_their_public_key: response.theirPublicKeyBase64 ?? void 0,
            inBandVerify: response.inBandVerify ?? "pending",
            serverVerify: response.serverVerify ?? "pending",
            serverVerifyError: response.serverVerifyError ?? void 0
          });
        }
      );
    });
  }
  async function isOnboarded(hostname) {
    if (!hostname) return false;
    return new Promise((resolve) => {
      chrome.storage.local.get([`veil_input_selector_${hostname}`], (data) => {
        resolve(!!data[`veil_input_selector_${hostname}`]);
      });
    });
  }
  var VERIFY_KEY_MAP = {
    pending: "verify_checking",
    verified: "verify_verified",
    failed: "verify_mismatch",
    error: "verify_unavailable"
  };
  function renderVerifyStatus(el, status, errorDetail) {
    el.className = `verify-status ${status}`;
    el.textContent = t(VERIFY_KEY_MAP[status]);
    if (errorDetail && (status === "failed" || status === "error")) {
      el.title = errorDetail;
    } else {
      el.title = "";
    }
  }
  function updateTooltips() {
    const tipMap = {
      tipStatus: "tip_status",
      tipFingerprint: "tip_fingerprint",
      tipInband: "tip_inband",
      tipServer: "tip_server",
      tipStartSession: "tip_start_session",
      tipEndSession: "tip_end_session",
      tipSetup: "tip_setup",
      tipReconfigure: "tip_reconfigure",
      tipLanguage: "tip_language"
    };
    for (const [id, key] of Object.entries(tipMap)) {
      const el = document.getElementById(id);
      if (el) el.setAttribute("data-tip", t(key));
    }
  }
  async function render() {
    const hostname = await getHostname();
    const state = await getSessionState();
    const onboarded = await isOnboarded(hostname);
    const handshakeState = state.veil_handshake_state ?? "idle";
    const hostnameEl = document.getElementById("hostname");
    hostnameEl.textContent = hostname || "No active tab";
    const dot = document.getElementById("statusDot");
    const statusText = document.getElementById("statusText");
    dot.className = `status-dot ${handshakeState}`;
    if (handshakeState === "established") {
      statusText.textContent = t("popup_connected");
    } else if (handshakeState === "invited") {
      statusText.textContent = t("popup_waiting_response");
    } else {
      statusText.textContent = t("popup_no_session");
    }
    const fpEl = document.getElementById("fingerprint");
    const fpLabel = document.getElementById("fingerprintLabel");
    const fpLabelText = document.getElementById("fingerprintLabelText");
    const verifySection = document.getElementById("verifySection");
    if (state.veil_fingerprint && handshakeState === "established") {
      fpEl.textContent = state.veil_fingerprint;
      fpEl.classList.remove("hidden");
      fpLabel.classList.remove("hidden");
      verifySection.classList.remove("hidden");
      fpLabelText.textContent = t("popup_compare_peer");
      document.getElementById("inBandLabel").textContent = t("popup_inband");
      document.getElementById("serverLabel").textContent = t("popup_server");
      const inBandEl = document.getElementById("inBandStatus");
      renderVerifyStatus(inBandEl, state.inBandVerify ?? "pending");
      const serverEl = document.getElementById("serverStatus");
      renderVerifyStatus(serverEl, state.serverVerify ?? "pending", state.serverVerifyError);
    } else {
      fpEl.classList.add("hidden");
      fpLabel.classList.add("hidden");
      verifySection.classList.add("hidden");
    }
    const btnStart = document.getElementById("btnStartSession");
    const btnEnd = document.getElementById("btnEndSession");
    const btnSetup = document.getElementById("btnSetup");
    const btnReconfigure = document.getElementById("btnReconfigure");
    const setupNeeded = document.getElementById("setupNeeded");
    document.getElementById("btnStartLabel").textContent = t("start_session");
    document.getElementById("btnEndLabel").textContent = t("end_session");
    document.getElementById("btnSetupLabel").textContent = t("popup_setup_site");
    document.getElementById("btnReconfigureLabel").textContent = t("popup_reconfigure");
    setupNeeded.textContent = t("popup_setup_needed");
    if (handshakeState === "established") {
      btnStart.classList.add("hidden");
      btnEnd.classList.remove("hidden");
      btnSetup.classList.add("hidden");
      btnReconfigure.classList.remove("hidden");
      setupNeeded.classList.add("hidden");
    } else if (handshakeState === "invited") {
      btnStart.classList.add("hidden");
      btnEnd.classList.remove("hidden");
      btnSetup.classList.add("hidden");
      btnReconfigure.classList.add("hidden");
      setupNeeded.classList.add("hidden");
    } else {
      btnEnd.classList.add("hidden");
      if (onboarded) {
        btnStart.classList.remove("hidden");
        btnStart.disabled = false;
        btnSetup.classList.add("hidden");
        btnReconfigure.classList.remove("hidden");
        setupNeeded.classList.add("hidden");
      } else {
        btnStart.classList.remove("hidden");
        btnStart.disabled = true;
        btnSetup.classList.remove("hidden");
        btnReconfigure.classList.add("hidden");
        setupNeeded.classList.remove("hidden");
      }
    }
    const lang = getLang();
    document.getElementById("langEn").classList.toggle("active", lang === "en");
    document.getElementById("langFa").classList.toggle("active", lang === "fa");
    document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
    document.documentElement.lang = lang === "fa" ? "fa" : "en";
    updateTooltips();
  }
  function bindEvents() {
    document.getElementById("btnStartSession").addEventListener("click", () => {
      sendToContent({ type: "START_SESSION" });
      window.close();
    });
    document.getElementById("btnEndSession").addEventListener("click", () => {
      sendToContent({ type: "END_SESSION" });
      window.close();
    });
    document.getElementById("btnSetup").addEventListener("click", () => {
      sendToContent({ type: "START_ONBOARDING" });
      window.close();
    });
    document.getElementById("btnReconfigure").addEventListener("click", () => {
      sendToContent({ type: "START_ONBOARDING" });
      window.close();
    });
    document.querySelectorAll(".lang-btn[data-lang]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const lang = btn.dataset.lang;
        setLang(lang);
        chrome.storage.local.set({ veil_lang: lang });
        sendToContent({ type: "SET_LANGUAGE", lang });
        render();
      });
    });
  }
  async function init() {
    chrome.storage.local.get(["veil_lang"], (data) => {
      if (data.veil_lang) {
        setLang(data.veil_lang);
      }
      render();
    });
    bindEvents();
  }
  init();
})();
