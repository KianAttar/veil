"use strict";
(() => {
  // src/background.ts
  chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" });
  function getActiveTab(callback) {
    chrome.tabs.query({ active: true }, (tabs) => {
      const candidates = tabs.filter((t) => t.url && !t.url.startsWith("chrome-extension://") && !t.url.startsWith("chrome://")).sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
      callback(candidates[0] ?? null);
    });
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.target === "content") {
      getActiveTab((tab) => {
        if (tab && tab.id !== void 0) {
          chrome.tabs.sendMessage(tab.id, message, (response) => {
            sendResponse(response);
          });
        } else {
          sendResponse(null);
        }
      });
      return true;
    }
    if (message.type === "GET_TAB_HOSTNAME") {
      getActiveTab((tab) => {
        if (tab && tab.url) {
          try {
            const url = new URL(tab.url);
            sendResponse({ hostname: url.hostname });
          } catch {
            sendResponse({ hostname: "" });
          }
        } else {
          sendResponse({ hostname: "" });
        }
      });
      return true;
    }
  });
})();
