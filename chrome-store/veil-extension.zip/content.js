"use strict";
(() => {
  // src/crypto.ts
  var IV_LENGTH = 12;
  var TAG_LENGTH = 128;
  var PROVENANCE_KEY_RAW = new Uint8Array([
    86,
    69,
    73,
    76,
    45,
    80,
    82,
    79,
    86,
    69,
    78,
    65,
    78,
    67,
    69,
    45,
    75,
    69,
    89,
    45,
    50,
    48,
    50,
    54,
    45,
    86,
    49,
    45,
    83,
    69,
    67,
    82
  ]);
  async function generateKeyPair() {
    return await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveKey", "deriveBits"]
    );
  }
  async function exportPublicKey(keyPair) {
    const raw = await crypto.subtle.exportKey("raw", keyPair.publicKey);
    return arrayBufferToBase64(raw);
  }
  async function importPublicKey(base64) {
    const raw = base64ToArrayBuffer(base64);
    return await crypto.subtle.importKey(
      "raw",
      raw,
      { name: "ECDH", namedCurve: "P-256" },
      true,
      []
    );
  }
  async function exportPrivateKey(keyPair) {
    const jwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
    return JSON.stringify(jwk);
  }
  async function importPrivateKey(jwkString) {
    const jwk = JSON.parse(jwkString);
    return await crypto.subtle.importKey(
      "jwk",
      jwk,
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveKey", "deriveBits"]
    );
  }
  async function deriveSharedKey(privateKey, publicKey) {
    const sharedBits = await crypto.subtle.deriveBits(
      { name: "ECDH", public: publicKey },
      privateKey,
      256
    );
    const hkdfKey = await crypto.subtle.importKey("raw", sharedBits, "HKDF", false, ["deriveKey"]);
    return await crypto.subtle.deriveKey(
      {
        name: "HKDF",
        hash: "SHA-256",
        salt: new TextEncoder().encode("veil-v1-salt"),
        info: new TextEncoder().encode("veil-v1-aes-key")
      },
      hkdfKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(aesKey, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));
    const encoded = new TextEncoder().encode(plaintext);
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, tagLength: TAG_LENGTH },
      aesKey,
      encoded
    );
    const result = new Uint8Array(IV_LENGTH + ciphertext.byteLength);
    result.set(iv, 0);
    result.set(new Uint8Array(ciphertext), IV_LENGTH);
    return arrayBufferToBase64(result.buffer);
  }
  async function decrypt(aesKey, base64Payload) {
    const data = new Uint8Array(base64ToArrayBuffer(base64Payload));
    const iv = data.slice(0, IV_LENGTH);
    const ciphertext = data.slice(IV_LENGTH);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv, tagLength: TAG_LENGTH },
      aesKey,
      ciphertext
    );
    return new TextDecoder().decode(decrypted);
  }
  async function computeFingerprint(publicKeyA, publicKeyB) {
    const [first, second] = [publicKeyA, publicKeyB].sort();
    const combined = first + ":" + second;
    const encoded = new TextEncoder().encode(combined);
    const hash = await crypto.subtle.digest("SHA-256", encoded);
    const bytes = new Uint8Array(hash);
    return Array.from(bytes.slice(0, 4)).map((b) => b.toString(16).toUpperCase().padStart(2, "0")).join("-");
  }
  async function getProvenanceKey() {
    return await crypto.subtle.importKey(
      "raw",
      PROVENANCE_KEY_RAW,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign", "verify"]
    );
  }
  async function signProvenance(publicKeyBase64) {
    const key = await getProvenanceKey();
    const data = new TextEncoder().encode(publicKeyBase64);
    const sig = await crypto.subtle.sign("HMAC", key, data);
    return arrayBufferToBase64(sig);
  }
  async function verifyProvenance(publicKeyBase64, signatureBase64) {
    const key = await getProvenanceKey();
    const data = new TextEncoder().encode(publicKeyBase64);
    const sig = base64ToArrayBuffer(signatureBase64);
    return await crypto.subtle.verify("HMAC", key, sig, data);
  }
  function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
  function base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }
  var VeilCrypto = {
    generateKeyPair,
    exportPublicKey,
    importPublicKey,
    exportPrivateKey,
    importPrivateKey,
    deriveSharedKey,
    encrypt,
    decrypt,
    computeFingerprint,
    signProvenance,
    verifyProvenance,
    arrayBufferToBase64,
    base64ToArrayBuffer
  };

  // src/disguise.ts
  var TAG_I_OPEN = "[VL:I]";
  var TAG_R_OPEN = "[VL:R]";
  var TAG_E_OPEN = "[VL:E]";
  var TAG_V_OPEN = "[VL:V]";
  var TAG_X_OPEN = "[VL:X]";
  var TAG_CLOSE = "[/VL]";
  function isAnyVeil(text) {
    return text.includes("[VL:");
  }
  function parseHandshakePayload(payload) {
    const parts = payload.split(".");
    if (parts.length !== 4) return null;
    const timestamp = parseInt(parts[3], 10);
    if (isNaN(timestamp)) return null;
    return {
      publicKey: parts[0],
      signature: parts[1],
      nonce: parts[2],
      timestamp
    };
  }
  function formatHandshakePayload(publicKey, signature, nonce, timestamp) {
    return `${publicKey}.${signature}.${nonce}.${timestamp}`;
  }
  function wrapInvite(publicKey, signature, nonce, timestamp) {
    return `${TAG_I_OPEN}${formatHandshakePayload(publicKey, signature, nonce, timestamp)}${TAG_CLOSE}`;
  }
  function unwrapInvite(text) {
    const start = text.indexOf(TAG_I_OPEN);
    if (start === -1) return null;
    const payloadStart = start + TAG_I_OPEN.length;
    const end = text.indexOf(TAG_CLOSE, payloadStart);
    if (end === -1) return null;
    return parseHandshakePayload(text.slice(payloadStart, end));
  }
  function isInvite(text) {
    return text.includes(TAG_I_OPEN);
  }
  function wrapReply(publicKey, signature, nonce, timestamp) {
    return `${TAG_R_OPEN}${formatHandshakePayload(publicKey, signature, nonce, timestamp)}${TAG_CLOSE}`;
  }
  function unwrapReply(text) {
    const start = text.indexOf(TAG_R_OPEN);
    if (start === -1) return null;
    const payloadStart = start + TAG_R_OPEN.length;
    const end = text.indexOf(TAG_CLOSE, payloadStart);
    if (end === -1) return null;
    return parseHandshakePayload(text.slice(payloadStart, end));
  }
  function isReply(text) {
    return text.includes(TAG_R_OPEN);
  }
  function wrapMessage(base64Ciphertext) {
    return `${TAG_E_OPEN}${base64Ciphertext}${TAG_CLOSE}`;
  }
  function unwrapMessage(text) {
    const start = text.indexOf(TAG_E_OPEN);
    if (start === -1) return null;
    const payloadStart = start + TAG_E_OPEN.length;
    const end = text.indexOf(TAG_CLOSE, payloadStart);
    if (end === -1) return null;
    return text.slice(payloadStart, end);
  }
  function isVeilMessage(text) {
    return text.includes(TAG_E_OPEN);
  }
  function wrapVerify(encryptedFingerprint) {
    return `${TAG_V_OPEN}${encryptedFingerprint}${TAG_CLOSE}`;
  }
  function unwrapVerify(text) {
    const start = text.indexOf(TAG_V_OPEN);
    if (start === -1) return null;
    const payloadStart = start + TAG_V_OPEN.length;
    const end = text.indexOf(TAG_CLOSE, payloadStart);
    if (end === -1) return null;
    return text.slice(payloadStart, end);
  }
  function isVerifyMessage(text) {
    return text.includes(TAG_V_OPEN);
  }
  function wrapEnd(encryptedTimestamp) {
    return `${TAG_X_OPEN}${encryptedTimestamp}${TAG_CLOSE}`;
  }
  function unwrapEnd(text) {
    const start = text.indexOf(TAG_X_OPEN);
    if (start === -1) return null;
    const payloadStart = start + TAG_X_OPEN.length;
    const end = text.indexOf(TAG_CLOSE, payloadStart);
    if (end === -1) return null;
    return text.slice(payloadStart, end);
  }
  function isEndMessage(text) {
    return text.includes(TAG_X_OPEN);
  }
  var VeilDisguise = {
    isAnyVeil,
    wrapInvite,
    unwrapInvite,
    isInvite,
    wrapReply,
    unwrapReply,
    isReply,
    wrapMessage,
    unwrapMessage,
    isVeilMessage,
    wrapVerify,
    unwrapVerify,
    isVerifyMessage,
    wrapEnd,
    unwrapEnd,
    isEndMessage,
    TAG_I_OPEN,
    TAG_R_OPEN,
    TAG_E_OPEN,
    TAG_V_OPEN,
    TAG_X_OPEN,
    TAG_CLOSE
  };

  // src/config.ts
  var VERIFY_SERVER_URL = false ? "http://localhost:8787" : "https://verify.veil.kiancode.dev";

  // src/content.ts
  (() => {
    let handshakeState = "idle";
    let sessionKey = null;
    let myKeyPair = null;
    let myPublicKeyBase64 = null;
    let theirPublicKeyBase64 = null;
    let myNonce = null;
    let establishedAt = 0;
    let fingerprint = null;
    let sessionEndedAt = 0;
    let lastEncryptedOutgoing = null;
    let inBandVerify = "pending";
    let serverVerify = "pending";
    let serverVerifyError = null;
    let onboardingMode = null;
    let observer = null;
    const processedNodes = /* @__PURE__ */ new WeakSet();
    const seenPayloads = /* @__PURE__ */ new Set();
    let annotationStyleInjected = false;
    function injectAnnotationStyle() {
      if (annotationStyleInjected) return;
      annotationStyleInjected = true;
      const style = document.createElement("style");
      style.textContent = `
      .veil-annotation {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        margin-top: 4px;
      }
      .veil-sep {
        display: block;
        font-size: 10px;
        letter-spacing: 2px;
        color: #6c63ff;
        opacity: 0.6;
        user-select: none;
      }
      .veil-msg {
        display: block;
        font-size: 13px;
        margin-top: 2px;
      }
      .veil-msg.success { color: #2ed573; }
      .veil-msg.error   { color: #ff4757; }
      .veil-msg.info    { color: #a0a0b8; }
    `;
      document.head.appendChild(style);
    }
    function annotateVeilNode(node, message, type = "info") {
      injectAnnotationStyle();
      const parent = node.parentElement;
      if (!parent) return;
      const annotation = document.createElement("div");
      annotation.className = "veil-annotation";
      const sep = document.createElement("span");
      sep.className = "veil-sep";
      sep.textContent = "---VEIL---";
      const msg = document.createElement("span");
      msg.className = `veil-msg ${type}`;
      msg.textContent = message;
      annotation.appendChild(sep);
      annotation.appendChild(msg);
      let insertBefore = node.nextSibling;
      while (insertBefore instanceof HTMLElement && insertBefore.classList.contains("veil-annotation")) {
        insertBefore = insertBefore.nextSibling;
      }
      parent.insertBefore(annotation, insertBefore);
    }
    function saveSessionToStorage() {
      if (!myKeyPair || !myPublicKeyBase64) return;
      VeilCrypto.exportPrivateKey(myKeyPair).then((privKey) => {
        const data = {
          veil_handshake_state: handshakeState,
          veil_private_key: privKey,
          veil_public_key: myPublicKeyBase64,
          veil_nonce: myNonce,
          veil_established_at: establishedAt
        };
        if (theirPublicKeyBase64) data.veil_their_public_key = theirPublicKeyBase64;
        if (fingerprint) data.veil_fingerprint = fingerprint;
        chrome.storage.session.set(data, () => {
          if (chrome.runtime.lastError) {
          } else {
          }
        });
      }).catch((err) => {
      });
    }
    function clearSession() {
      handshakeState = "idle";
      sessionKey = null;
      myKeyPair = null;
      myPublicKeyBase64 = null;
      theirPublicKeyBase64 = null;
      myNonce = null;
      establishedAt = 0;
      fingerprint = null;
      seenPayloads.clear();
      inBandVerify = "pending";
      serverVerify = "pending";
      serverVerifyError = null;
      chrome.storage.session.remove([
        "veil_handshake_state",
        "veil_private_key",
        "veil_public_key",
        "veil_their_public_key",
        "veil_nonce",
        "veil_established_at",
        "veil_fingerprint"
      ]);
      removeVeilToggle();
    }
    async function endSession() {
      if (sessionKey) {
        try {
          const ts = nowSeconds().toString();
          const encrypted = await VeilCrypto.encrypt(sessionKey, ts);
          const wrapped = VeilDisguise.wrapEnd(encrypted);
          await injectAndSend(wrapped);
        } catch (err) {
        }
      }
      sessionEndedAt = nowSeconds();
      clearSession();
      showToast("Session ended", "info");
    }
    async function restoreSession() {
      return new Promise((resolve) => {
        chrome.storage.session.get([
          "veil_handshake_state",
          "veil_private_key",
          "veil_public_key",
          "veil_their_public_key",
          "veil_nonce",
          "veil_established_at",
          "veil_fingerprint"
        ], async (data) => {
          if (!data) {
            resolve();
            return;
          }
          const state = data.veil_handshake_state;
          if (!state || state === "idle" || !data.veil_private_key || !data.veil_public_key) {
            resolve();
            return;
          }
          try {
            const privateKey = await VeilCrypto.importPrivateKey(data.veil_private_key);
            const publicKey = await VeilCrypto.importPublicKey(data.veil_public_key);
            myKeyPair = { privateKey, publicKey };
            myPublicKeyBase64 = data.veil_public_key;
            myNonce = data.veil_nonce ?? null;
            establishedAt = data.veil_established_at ?? 0;
            fingerprint = data.veil_fingerprint ?? null;
            handshakeState = state;
            if (state === "established" && data.veil_their_public_key) {
              theirPublicKeyBase64 = data.veil_their_public_key;
              const theirKey = await VeilCrypto.importPublicKey(theirPublicKeyBase64);
              sessionKey = await VeilCrypto.deriveSharedKey(myKeyPair.privateKey, theirKey);
              showVeilToggle();
            }
          } catch (err) {
            clearSession();
          }
          resolve();
        });
      });
    }
    function generateNonce() {
      const bytes = crypto.getRandomValues(new Uint8Array(8));
      let binary = "";
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      return btoa(binary);
    }
    function nowSeconds() {
      return Math.floor(Date.now() / 1e3);
    }
    async function startSession() {
      const existingInvite = scanForInvite();
      if (existingInvite) {
        await acceptInvite(existingInvite);
        return;
      }
      myKeyPair = await VeilCrypto.generateKeyPair();
      myPublicKeyBase64 = await VeilCrypto.exportPublicKey(myKeyPair);
      const sig = await VeilCrypto.signProvenance(myPublicKeyBase64);
      myNonce = generateNonce();
      const ts = nowSeconds();
      const wrapped = VeilDisguise.wrapInvite(myPublicKeyBase64, sig, myNonce, ts);
      handshakeState = "invited";
      saveSessionToStorage();
      await injectAndSend(wrapped);
    }
    function scanForInvite() {
      const cutoff = Math.max(nowSeconds() - 600, sessionEndedAt);
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
      let node;
      let best = null;
      while (node = walker.nextNode()) {
        const text = node.textContent;
        if (!text || text.length < 10) continue;
        if (!VeilDisguise.isInvite(text)) continue;
        const data = VeilDisguise.unwrapInvite(text);
        if (!data) continue;
        if (data.timestamp <= cutoff) continue;
        if (data.publicKey === myPublicKeyBase64) continue;
        if (!best || data.timestamp > best.timestamp) {
          best = data;
        }
      }
      return best;
    }
    async function acceptInvite(invite) {
      try {
        const valid = await VeilCrypto.verifyProvenance(invite.publicKey, invite.signature);
        if (!valid) {
          return;
        }
        myKeyPair = await VeilCrypto.generateKeyPair();
        myPublicKeyBase64 = await VeilCrypto.exportPublicKey(myKeyPair);
        theirPublicKeyBase64 = invite.publicKey;
        const theirKey = await VeilCrypto.importPublicKey(theirPublicKeyBase64);
        sessionKey = await VeilCrypto.deriveSharedKey(myKeyPair.privateKey, theirKey);
        fingerprint = await VeilCrypto.computeFingerprint(myPublicKeyBase64, theirPublicKeyBase64);
        const sig = await VeilCrypto.signProvenance(myPublicKeyBase64);
        const reply = VeilDisguise.wrapReply(myPublicKeyBase64, sig, invite.nonce, nowSeconds());
        const verifyPayload = await VeilCrypto.encrypt(sessionKey, fingerprint);
        const verify = VeilDisguise.wrapVerify(verifyPayload);
        handshakeState = "established";
        establishedAt = nowSeconds();
        saveSessionToStorage();
        showVeilToggle();
        await injectAndSend(reply + verify);
        verifyViaServer();
      } catch (err) {
      }
    }
    async function completeHandshake(reply) {
      try {
        const valid = await VeilCrypto.verifyProvenance(reply.publicKey, reply.signature);
        if (!valid) {
          return;
        }
        theirPublicKeyBase64 = reply.publicKey;
        const theirKey = await VeilCrypto.importPublicKey(theirPublicKeyBase64);
        sessionKey = await VeilCrypto.deriveSharedKey(myKeyPair.privateKey, theirKey);
        fingerprint = await VeilCrypto.computeFingerprint(myPublicKeyBase64, theirPublicKeyBase64);
        handshakeState = "established";
        establishedAt = nowSeconds();
        saveSessionToStorage();
        showVeilToggle();
        const verifyPayload = await VeilCrypto.encrypt(sessionKey, fingerprint);
        const verify = VeilDisguise.wrapVerify(verifyPayload);
        await injectAndSend(verify);
        verifyViaServer();
      } catch (err) {
      }
    }
    async function handleVerify(node, encryptedPayload) {
      if (!sessionKey || !theirPublicKeyBase64 || !myPublicKeyBase64) {
        annotateVeilNode(node, "Cannot verify \u2014 no active session", "error");
        return;
      }
      try {
        const received = await VeilCrypto.decrypt(sessionKey, encryptedPayload);
        const expected = await VeilCrypto.computeFingerprint(theirPublicKeyBase64, myPublicKeyBase64);
        if (received !== expected) {
          showToast("Fingerprint mismatch! Possible MITM attack.", "danger");
          annotateVeilNode(node, "Fingerprint MISMATCH \u2014 possible MITM!", "error");
          inBandVerify = "failed";
        } else {
          annotateVeilNode(node, "Fingerprint verified: " + received, "success");
          inBandVerify = "verified";
        }
      } catch (err) {
        annotateVeilNode(node, "Verification failed \u2014 decrypt error", "error");
        inBandVerify = "error";
      }
    }
    async function verifyViaServer() {
      if (!fingerprint || !myPublicKeyBase64 || !theirPublicKeyBase64) return;
      const url = VERIFY_SERVER_URL;
      try {
        const resp = await fetch(`${url}/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            publicKey: myPublicKeyBase64,
            fingerprint
          })
        });
        if (!resp.ok) {
          serverVerify = "error";
          serverVerifyError = "Server returned " + resp.status;
          return;
        }
      } catch (err) {
        serverVerify = "error";
        serverVerifyError = "Server unreachable";
        return;
      }
      const maxAttempts = 5;
      const retryDelay = 2e3;
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          const resp = await fetch(
            `${url}/verify?publicKey=${encodeURIComponent(theirPublicKeyBase64)}`
          );
          const data = await resp.json();
          if (!data.found) {
            await new Promise((r) => setTimeout(r, retryDelay));
            continue;
          }
          if (data.fingerprint === fingerprint) {
            showToast("Server verified \u2014 no MITM detected", "success");
            serverVerify = "verified";
          } else {
            showToast("SERVER VERIFICATION FAILED \u2014 possible MITM!", "danger");
            serverVerify = "failed";
            serverVerifyError = "Peer fingerprint: " + data.fingerprint;
          }
          return;
        } catch (err) {
          serverVerify = "error";
          serverVerifyError = "Network error";
          return;
        }
      }
      serverVerify = "error";
      serverVerifyError = "Peer not found (timed out)";
    }
    function startObserver() {
      if (observer) return;
      scanExistingNodes();
      let mutationCount = 0;
      observer = new MutationObserver((mutations) => {
        mutationCount++;
        for (const mutation of mutations) {
          mutation.addedNodes.forEach((node) => {
            processNode(node);
          });
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    function stopObserver() {
      if (observer) {
        observer.disconnect();
        observer = null;
      }
    }
    function scanExistingNodes() {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
      let node;
      while (node = walker.nextNode()) {
        processTextNode(node);
      }
    }
    function processNode(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        processTextNode(node);
        return;
      }
      if (node.nodeType === Node.ELEMENT_NODE) {
        const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null);
        let child;
        while (child = walker.nextNode()) {
          processTextNode(child);
        }
      }
    }
    function processTextNode(node) {
      const text = node.textContent;
      if (!text || text.length < 10) return;
      if (processedNodes.has(node)) return;
      if (!VeilDisguise.isAnyVeil(text)) return;
      const toggle = document.getElementById("veil-toggle-container");
      if (toggle && toggle.contains(node)) return;
      const toast = document.getElementById("veil-toast");
      if (toast && toast.contains(node)) return;
      processedNodes.add(node);
      if (VeilDisguise.isEndMessage(text)) {
        handleEndNode(node, text);
        return;
      }
      if (VeilDisguise.isVeilMessage(text)) {
        handleEncryptedNode(node, text);
      }
      if (VeilDisguise.isInvite(text)) {
        handleInviteNode(node, text);
      }
      if (VeilDisguise.isReply(text)) {
        handleReplyNode(node, text);
      }
      if (VeilDisguise.isVerifyMessage(text)) {
        handleVerifyNode(node, text);
      }
    }
    async function handleEncryptedNode(node, text) {
      if (!sessionKey) {
        annotateVeilNode(node, "No active session \u2014 cannot decrypt", "error");
        return;
      }
      const payload = VeilDisguise.unwrapMessage(text);
      if (!payload || seenPayloads.has(payload)) return;
      seenPayloads.add(payload);
      try {
        const plaintext = await VeilCrypto.decrypt(sessionKey, payload);
        annotateVeilNode(node, "\u{1F512} " + plaintext, "success");
      } catch {
        annotateVeilNode(node, "Could not decrypt \u2014 wrong session or corrupted", "error");
      }
    }
    function handleInviteNode(node, text) {
      const data = VeilDisguise.unwrapInvite(text);
      if (!data) return;
      if (data.timestamp <= sessionEndedAt) {
        annotateVeilNode(node, "Stale invite \u2014 from ended session", "info");
        return;
      }
      if (data.publicKey === myPublicKeyBase64) {
        annotateVeilNode(node, "Your handshake invite \u2014 waiting for response", "info");
        return;
      }
      const key = `invite:${data.publicKey}`;
      if (seenPayloads.has(key)) return;
      seenPayloads.add(key);
      if (handshakeState === "idle") {
        annotateVeilNode(node, "Handshake invite \u2014 start a session to accept", "info");
        return;
      }
      if (handshakeState === "invited") {
        annotateVeilNode(node, "Handshake invite \u2014 accepting...", "info");
        acceptInvite(data);
        return;
      }
      if (handshakeState === "established") {
        if (data.timestamp <= establishedAt) {
          annotateVeilNode(node, "Old handshake invite \u2014 ignored", "info");
          return;
        }
        if (confirm("Veil: New connection request received. Accept and reset current session?")) {
          clearSession();
          acceptInvite(data);
        } else {
          annotateVeilNode(node, "Handshake invite \u2014 declined", "info");
        }
      }
    }
    async function handleReplyNode(node, text) {
      const data = VeilDisguise.unwrapReply(text);
      if (!data) {
        return;
      }
      if (data.timestamp <= sessionEndedAt) {
        annotateVeilNode(node, "Stale reply \u2014 from ended session", "info");
        return;
      }
      if (data.publicKey === myPublicKeyBase64) {
        annotateVeilNode(node, "Your handshake reply", "info");
        return;
      }
      const key = `reply:${data.publicKey}`;
      if (seenPayloads.has(key)) {
        return;
      }
      seenPayloads.add(key);
      if (handshakeState !== "invited") {
        annotateVeilNode(node, "Handshake reply \u2014 no pending invite", "info");
        return;
      }
      if (data.nonce !== myNonce) {
        annotateVeilNode(node, "Handshake reply \u2014 nonce mismatch", "error");
        return;
      }
      await completeHandshake(data);
      annotateVeilNode(node, "Handshake complete \u2014 session established", "success");
      if (VeilDisguise.isVerifyMessage(text)) {
        handleVerifyNode(node, text);
      }
    }
    function handleVerifyNode(node, text) {
      const payload = VeilDisguise.unwrapVerify(text);
      if (!payload) return;
      if (seenPayloads.has(`verify:${payload}`)) return;
      seenPayloads.add(`verify:${payload}`);
      handleVerify(node, payload);
    }
    async function handleEndNode(node, text) {
      const payload = VeilDisguise.unwrapEnd(text);
      if (!payload) return;
      if (seenPayloads.has(`end:${payload}`)) return;
      seenPayloads.add(`end:${payload}`);
      if (!sessionKey) {
        annotateVeilNode(node, "Session end signal", "info");
        return;
      }
      try {
        const tsStr = await VeilCrypto.decrypt(sessionKey, payload);
        const ts = parseInt(tsStr, 10);
        if (isNaN(ts)) {
          annotateVeilNode(node, "Session end signal \u2014 invalid", "error");
          return;
        }
        sessionEndedAt = ts;
        clearSession();
        showToast("Peer ended the session", "info");
        annotateVeilNode(node, "Session ended by peer", "error");
      } catch {
        annotateVeilNode(node, "Session end signal \u2014 could not verify", "error");
      }
    }
    async function getInputSelector() {
      const hostname = window.location.hostname;
      return new Promise((resolve) => {
        chrome.storage.local.get([
          `veil_input_selector_${hostname}`,
          `veil_send_selector_${hostname}`
        ], (data) => {
          if (!data) {
            resolve({});
            return;
          }
          resolve({
            inputSelector: data[`veil_input_selector_${hostname}`],
            sendSelector: data[`veil_send_selector_${hostname}`]
          });
        });
      });
    }
    async function injectAndSend(text) {
      const { inputSelector, sendSelector } = await getInputSelector();
      const inputEl = inputSelector ? document.querySelector(inputSelector) : null;
      if (!inputEl) {
        return;
      }
      if (inputEl.getAttribute("contenteditable") !== null) {
        inputEl.focus();
        inputEl.innerHTML = "";
        inputEl.textContent = text;
        inputEl.dispatchEvent(new Event("input", { bubbles: true }));
        inputEl.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        inputEl.focus();
        inputEl.value = text;
        inputEl.dispatchEvent(new Event("input", { bubbles: true }));
        inputEl.dispatchEvent(new Event("change", { bubbles: true }));
      }
      await new Promise((r) => setTimeout(r, 100));
      if (sendSelector) {
        const sendBtn = document.querySelector(sendSelector);
        if (sendBtn) {
          sendBtn.click();
          return;
        }
      }
      inputEl.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true
        })
      );
    }
    let veilEnabled = false;
    function showVeilToggle() {
      if (document.getElementById("veil-toggle-container")) return;
      getInputSelector().then(({ inputSelector }) => {
        if (!inputSelector) return;
        const inputEl = document.querySelector(inputSelector);
        if (!inputEl) return;
        const style = document.createElement("style");
        style.textContent = `
        #veil-toggle-container {
          position: fixed;
          z-index: 2147483647;
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 16px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          user-select: none;
          transition: background 0.2s, color 0.2s;
          pointer-events: auto;
        }
        #veil-toggle-container.enabled {
          background: rgba(46, 213, 115, 0.15);
          color: #2ed573;
          border: 1px solid rgba(46, 213, 115, 0.3);
        }
        #veil-toggle-container.disabled {
          background: rgba(136, 136, 160, 0.15);
          color: #8888a0;
          border: 1px solid rgba(136, 136, 160, 0.3);
        }
      `;
        document.head.appendChild(style);
        const container = document.createElement("div");
        container.id = "veil-toggle-container";
        container.title = "When ON, pressing Enter encrypts your message before sending";
        container.innerHTML = `
        <span id="veil-toggle-icon"></span>
        <span id="veil-toggle-label"></span>
      `;
        document.body.appendChild(container);
        function positionToggle() {
          const rect = inputEl.getBoundingClientRect();
          container.style.top = `${rect.top - 30}px`;
          container.style.right = `${window.innerWidth - rect.right}px`;
        }
        positionToggle();
        window.addEventListener("scroll", positionToggle, { passive: true });
        window.addEventListener("resize", positionToggle, { passive: true });
        veilEnabled = true;
        updateToggleUI();
        container.addEventListener("click", () => {
          veilEnabled = !veilEnabled;
          updateToggleUI();
        });
        setupSendInterception(inputSelector);
      });
    }
    function removeVeilToggle() {
      const el = document.getElementById("veil-toggle-container");
      if (el) el.remove();
      veilEnabled = false;
    }
    function updateToggleUI() {
      const container = document.getElementById("veil-toggle-container");
      if (!container) return;
      const icon = document.getElementById("veil-toggle-icon");
      const label = document.getElementById("veil-toggle-label");
      if (veilEnabled) {
        container.className = "enabled";
        icon.textContent = "\u{1F512}";
        label.textContent = "Veil: ON";
      } else {
        container.className = "disabled";
        icon.textContent = "\u{1F513}";
        label.textContent = "Veil: OFF";
      }
    }
    function setupSendInterception(inputSelector) {
      document.addEventListener("keydown", async (e) => {
        if (!veilEnabled || !sessionKey) return;
        if (e.key !== "Enter" || e.shiftKey) return;
        const target = e.target;
        const inputEl = document.querySelector(inputSelector);
        if (!inputEl || target !== inputEl) return;
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        let plaintext = "";
        if (inputEl.getAttribute("contenteditable") !== null) {
          plaintext = (inputEl.textContent ?? "").trim();
        } else {
          plaintext = (inputEl.value ?? "").trim();
        }
        if (!plaintext) return;
        try {
          const ciphertext = await VeilCrypto.encrypt(sessionKey, plaintext);
          const wrapped = VeilDisguise.wrapMessage(ciphertext);
          lastEncryptedOutgoing = wrapped;
          if (inputEl.getAttribute("contenteditable") !== null) {
            inputEl.innerHTML = "";
            inputEl.textContent = wrapped;
            inputEl.dispatchEvent(new Event("input", { bubbles: true }));
          } else {
            inputEl.value = wrapped;
            inputEl.dispatchEvent(new Event("input", { bubbles: true }));
          }
          await new Promise((r) => setTimeout(r, 50));
          const { sendSelector } = await getInputSelector();
          if (sendSelector) {
            const sendBtn = document.querySelector(sendSelector);
            if (sendBtn) {
              sendBtn.click();
              return;
            }
          }
          inputEl.dispatchEvent(
            new KeyboardEvent("keydown", {
              key: "Enter",
              code: "Enter",
              keyCode: 13,
              which: 13,
              bubbles: true
            })
          );
        } catch (err) {
        }
      }, true);
    }
    function startOnboarding() {
      onboardingMode = "input";
      showToast("Type something in the chat input...", "info");
      document.addEventListener("input", onboardingInputHandler, true);
    }
    function onboardingInputHandler(e) {
      if (onboardingMode !== "input") return;
      const el = e.target;
      if (!el || el.id === "veil-toast") return;
      const isInput = el.tagName === "TEXTAREA" || el.tagName === "INPUT" || el.getAttribute("contenteditable") !== null;
      if (!isInput) return;
      const selector = generateSelector(el);
      const hostname = window.location.hostname;
      chrome.storage.local.set({ [`veil_input_selector_${hostname}`]: selector }, () => {
        document.removeEventListener("input", onboardingInputHandler, true);
        onboardingMode = "send";
        showToast("Now click the send button...", "info");
        document.addEventListener("click", onboardingSendHandler, true);
      });
    }
    function onboardingSendHandler(e) {
      if (onboardingMode !== "send") return;
      const el = e.target;
      const toast = document.getElementById("veil-toast");
      if (toast && toast.contains(el)) return;
      e.preventDefault();
      e.stopPropagation();
      const selector = generateSelector(el);
      const hostname = window.location.hostname;
      chrome.storage.local.set({ [`veil_send_selector_${hostname}`]: selector }, () => {
        document.removeEventListener("click", onboardingSendHandler, true);
        onboardingMode = null;
        showToast("Setup complete!", "success");
      });
    }
    function generateSelector(el) {
      if (el.id) return "#" + CSS.escape(el.id);
      const path = [];
      let current = el;
      while (current && current !== document.body) {
        let seg = current.tagName.toLowerCase();
        if (current.id) {
          seg = "#" + CSS.escape(current.id);
          path.unshift(seg);
          break;
        }
        if (current.className && typeof current.className === "string") {
          const classes = current.className.trim().split(/\s+/).slice(0, 2);
          if (classes.length > 0 && classes[0]) {
            seg += "." + classes.map((c) => CSS.escape(c)).join(".");
          }
        }
        const parent = current.parentElement;
        if (parent) {
          const siblings = Array.from(parent.children).filter(
            (c) => c.tagName === current.tagName
          );
          if (siblings.length > 1) {
            const idx = siblings.indexOf(current) + 1;
            seg += `:nth-of-type(${idx})`;
          }
        }
        path.unshift(seg);
        current = current.parentElement;
      }
      return path.join(" > ");
    }
    function showToast(message, type = "info") {
      let toast = document.getElementById("veil-toast");
      if (!toast) {
        toast = document.createElement("div");
        toast.id = "veil-toast";
        const style = document.createElement("style");
        style.textContent = `
        #veil-toast {
          position: fixed;
          top: 16px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 2147483647;
          padding: 10px 20px;
          border-radius: 8px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 14px;
          font-weight: 500;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          transition: opacity 0.3s;
          pointer-events: none;
        }
        #veil-toast.info { background: #1a1a2e; color: #e0e0e8; border: 1px solid #6c63ff; }
        #veil-toast.success { background: #1a2e1a; color: #2ed573; border: 1px solid #2ed573; }
        #veil-toast.danger { background: #2e1a1a; color: #ff4757; border: 1px solid #ff4757; }
      `;
        document.head.appendChild(style);
        document.body.appendChild(toast);
      }
      toast.textContent = message;
      toast.className = type;
      toast.style.opacity = "1";
      if (type !== "info" || !onboardingMode) {
        setTimeout(() => {
          if (toast) toast.style.opacity = "0";
          setTimeout(() => toast?.remove(), 300);
        }, 3e3);
      }
    }
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      switch (message.type) {
        case "START_SESSION":
          startSession();
          sendResponse({ ok: true });
          break;
        case "END_SESSION":
          endSession();
          sendResponse({ ok: true });
          break;
        case "START_ONBOARDING":
          startOnboarding();
          sendResponse({ ok: true });
          break;
        case "GET_SESSION_STATE":
          sendResponse({
            handshakeState,
            fingerprint,
            myPublicKeyBase64,
            theirPublicKeyBase64,
            inBandVerify,
            serverVerify,
            serverVerifyError
          });
          break;
        case "DEBUG_SCAN":
          scanExistingNodes();
          sendResponse({ ok: true, state: handshakeState, myNonce });
          break;
        case "DEBUG_GET_LAST_ENCRYPTED":
          sendResponse({ encrypted: lastEncryptedOutgoing });
          lastEncryptedOutgoing = null;
          break;
      }
    });
    async function init() {
      startObserver();
    }
    init();
  })();
})();
